package ca.uwaterloo.view.components

import androidx.compose.runtime.*

@Composable
fun SignOutButton() {
}
